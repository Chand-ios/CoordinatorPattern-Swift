//
//  ViewController.swift
//  CoordinaatorPatternApp
//
//  Created by eAlphaMac2 on 17/06/21.
//

import UIKit

class ViewController: UIViewController, Coordinating {
    
    var coordinator: Coordinator?

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .red
        title = "HOME"
        
        let button = UIButton(frame: CGRect(x: 0, y: 0, width: 220, height: 55))
        view.addSubview(button)
        button.center = view.center
        button.backgroundColor = .systemGreen
        button.setTitleColor(.white, for: .normal)
        button.addTarget(self, action: #selector(didTapButton), for: .touchUpInside)
        button.setTitle("TapMe", for: .normal)
        
    }
    
    @objc func didTapButton()
    {
        coordinator?.eventOccured(with: .buttonTapped)
    }


}

