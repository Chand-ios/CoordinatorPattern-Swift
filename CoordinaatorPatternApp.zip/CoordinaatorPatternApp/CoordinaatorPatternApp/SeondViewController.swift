//
//  SeondViewController.swift
//  CoordinaatorPatternApp
//
//  Created by eAlphaMac2 on 17/06/21.
//

import UIKit

class SeondViewController: UIViewController, Coordinating {
    var coordinator: Coordinator?

    override func viewDidLoad() {
        super.viewDidLoad()

        title = "Second"
        view.backgroundColor = .systemBlue
    }
    

}
