//
//  MainCoordinator.swift
//  CoordinaatorPatternApp
//
//  Created by eAlphaMac2 on 17/06/21.
//

import Foundation
import UIKit


class MainCoordinator: Coordinator {
    var navigationController: UINavigationController?
    
    func eventOccured(with type: Event) {
        switch type {
        case .buttonTapped:
            var vc : UIViewController & Coordinating = SeondViewController()
            vc.coordinator = self
            navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    func start() {
        let vc: ViewController & Coordinating = ViewController()
        vc.coordinator = self
        navigationController?.setViewControllers([vc],animated: false)
    }
    
    
}
